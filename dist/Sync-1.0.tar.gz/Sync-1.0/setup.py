from setuptools import setup, find_packages

setup(
    name='Sync',
    version='1.0',
    author='Kapa Kudaibergenov',
    author_email='kudkapa59@gmail.com',
    packages=find_packages(),
)